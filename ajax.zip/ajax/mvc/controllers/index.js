
getIndex = function(req, res, next) {
  res.render('index', { title: 'RESTful Routing' });
}

getExample = function(req, res, next) {
  res.render('example', { title: 'example' });
}

getReqExample =  function(req, res, next) {
  res.json({message: 'User made  GET req'});
}

postReqExample =  function(req, res, next) {
  res.json({message: 'User made POST req'});
}

putReqExample =  function(req, res, next) {
  res.json({message: 'User made  PUT req'});
}

deleteReqExample =  function(req, res, next) {
  res.json({message: 'User made  DELETE req'});
}

getRestful =  function(req, res, next) {
  res.render('restful', { title: 'RESTful Routing' });
}


module.exports = {
    getIndex,
    getExample,
    getReqExample,
    postReqExample,
    putReqExample,
    deleteReqExample,
    getRestful
}
